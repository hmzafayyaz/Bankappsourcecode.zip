package com.bankapp;

class DeficientFundsException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DeficientFundsException() {
        super("Insufficient funds for this withdrawal.");
    }

    public DeficientFundsException(String message) {
        super(message);
    }
}
