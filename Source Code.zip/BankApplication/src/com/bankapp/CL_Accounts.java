
package com.bankapp;

class Cl_Accounts {
    private long Accnt_No;
    private String client_fname;
    private String client_lname;
    private float client_balance;
    private static long Nxt_Accnt_No = 0;

    public Cl_Accounts() {}

    public Cl_Accounts(String fname, String lname, float client_balance) {
        Nxt_Accnt_No++;
        this.Accnt_No = Nxt_Accnt_No;
        this.client_fname = fname;
        this.client_lname = lname;
        this.client_balance = client_balance;
    }

    public long getAccNo() {
        return Accnt_No;
    }

    public String getFName() {
        return client_fname;
    }

    public String getLName() {
        return client_lname;
    }

    public float getBalance() {
        return client_balance;
    }

    public void deposit(float amount) {
        client_balance += amount;
    }

    public void withdraw(float amount) throws DeficientFundsException {
        if (client_balance - amount < 100) {
            throw new DeficientFundsException();
        }
        client_balance -= amount;
    }

    public static void setLastAccntNo(long Accnt_No) {
        Nxt_Accnt_No = Accnt_No;
    }

    public static long getLastAccntNo() {
        return Nxt_Accnt_No;
    }

    @Override
    public String toString() {
        return "First Name: " + client_fname + "\n" +
               "Last Name: " + client_lname + "\n" +
               "Account Number: " + Accnt_No + "\n" +
               "Balance: " + client_balance + "\n";
    }
}
